const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');
const session = require ('express-session');
const flash = require( 'express-flash');
const {QuotesRouter} = require('./server/routes/quotesRouter');
const app = express();

// Database connection
mongoose.connect('mongodb://localhost/quoting_dojo_routes');

app.use(flash());
// Body parser data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 * 10 }
}));

// Point server to views
app.set('views', path.join(__dirname, '/client/views'));
//using ejs as our view engine
app.set('view engine', 'ejs');
app.use('/', QuotesRouter);

//port
app.listen(8000, function(){
    console.log( "The QD server is running in port 8000");
});
